<?php

include 'includes/header.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nombre = trim(strip_tags($_POST['nombre']));
    $apellido = trim(strip_tags($_POST['apellido']));
    $identificacion = trim(strip_tags($_POST['identificacion']));
    $fechaNacimiento = $_POST['fecha_nacimiento'];
    $sexo = $_POST['sexo'];

    $nombre = ucwords(strtolower($nombre));
    $apellido = ucwords(strtolower($apellido));
    $identificacion = strtoupper($identificacion);

    if (
        empty($nombre) ||
        empty($apellido) ||
        empty($identificacion) ||
        empty($fechaNacimiento) ||
        empty($sexo)
    ) {
        echo '<div class="container my-5">';
        echo '<div class="alert alert-danger">';
        echo 'Todos los campos son obligatorios.';
        echo '</div>';
        echo '</div>';

        include 'includes/footer.php';
        exit;
    }

    $fechaNacimientoObjeto = new DateTime($fechaNacimiento);
    $fechaActual = new DateTime();

    $edad = $fechaActual->diff($fechaNacimientoObjeto)->y;

    if ($edad < 18 || $edad > 70) {

        echo '<div class="container my-5">';
        echo '<div class="alert alert-danger">';
        echo 'La edad del aspirante debe estar entre 18 y 70 años.';
        echo '</div>';
        echo '<a href="index.php" class="btn btn-secondary">Regresar</a>';
        echo '</div>';

        include 'includes/footer.php';
        exit;
    }

    $fotoGuardada = "";

    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {

        $nombreArchivo = $_FILES['foto']['name'];
        $archivoTemporal = $_FILES['foto']['tmp_name'];

        $extension = strtolower(pathinfo($nombreArchivo, PATHINFO_EXTENSION));

        $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'gif', 'webp'];

        if (!in_array($extension, $extensionesPermitidas)) {

            echo '<div class="container my-5">';
            echo '<div class="alert alert-danger">';
            echo 'El formato de la fotografía no está permitido.';
            echo '</div>';
            echo '<a href="index.php" class="btn btn-secondary">Regresar</a>';
            echo '</div>';

            include 'includes/footer.php';
            exit;
        }

        $nuevoNombre = uniqid('aspirante_', true) . '.' . $extension;

        $rutaDestino = 'uploaded_files/' . $nuevoNombre;

        if (move_uploaded_file($archivoTemporal, $rutaDestino)) {
            $fotoGuardada = $rutaDestino;
        }
    }

    ?>

    <main class="container my-5">

        <section>

            <div class="card shadow-sm">

                <div class="card-body p-4">

                    <h1 class="mb-4">
                        Registro Procesado Correctamente
                    </h1>

                    <p>
                        <strong>Nombre:</strong>
                        <?php echo htmlspecialchars($nombre); ?>
                    </p>

                    <p>
                        <strong>Apellido:</strong>
                        <?php echo htmlspecialchars($apellido); ?>
                    </p>

                    <p>
                        <strong>Identificación:</strong>
                        <?php echo htmlspecialchars($identificacion); ?>
                    </p>

                    <p>
                        <strong>Edad:</strong>
                        <?php echo $edad; ?> años
                    </p>

                    <p>
                        <strong>Sexo:</strong>
                        <?php echo htmlspecialchars($sexo); ?>
                    </p>

                    <?php if (!empty($fotoGuardada)): ?>

                        <div class="mt-4">

                            <p>
                                <strong>Fotografía:</strong>
                            </p>

                            <img
                                src="<?php echo htmlspecialchars($fotoGuardada); ?>"
                                alt="Fotografía del aspirante"
                                class="img-thumbnail"
                                style="max-width: 250px;">

                        </div>

                    <?php endif; ?>

                    <div class="mt-4">

                        <a href="index.php" class="btn btn-primary">
                            Registrar otro aspirante
                        </a>

                    </div>

                </div>

            </div>

        </section>

    </main>

    <?php
}

include 'includes/footer.php';

?>