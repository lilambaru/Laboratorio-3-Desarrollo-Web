<?php 
include 'includes/header.php'; 
?> 

<main class="container my-5">

    <section>
        <div class="card shadow-sm">
            <div class="card-body p-4">

                <h1 class="mb-4">Formulario de Registro de Aspirantes</h1>

                <form action="procesar.php" method="POST" enctype="multipart/form-data">

                    <div class="mb-3">
                        <label for="nombre" class="form-label">
                            Nombre (Requerido):
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="nombre"
                            name="nombre"
                            placeholder="Ingrese su nombre"
                            required>
                    </div>

                    <div class="mb-3">
                        <label for="apellido" class="form-label">
                            Apellido (Requerido):
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="apellido"
                            name="apellido"
                            placeholder="Ingrese su apellido"
                            required>
                    </div>

                    <div class="mb-3">
                        <label for="identificacion" class="form-label">
                            Identificación (Requerido):
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            id="identificacion"
                            name="identificacion"
                            placeholder="Ingrese su identificación"
                            required>
                    </div>

                    <div class="mb-3">
                        <label for="fecha_nacimiento" class="form-label">
                            Fecha de Nacimiento (Requerido):
                        </label>

                        <input
                            type="date"
                            class="form-control"
                            id="fecha_nacimiento"
                            name="fecha_nacimiento"
                            required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">
                            Sexo (Requerido):
                        </label>

                        <div class="d-flex gap-4">

                            <div class="form-check">
                                <input
                                    class="form-check-input"
                                    type="radio"
                                    name="sexo"
                                    id="hombre"
                                    value="Hombre"
                                    required>

                                <label class="form-check-label" for="hombre">
                                    Hombre
                                </label>
                            </div>

                            <div class="form-check">
                                <input
                                    class="form-check-input"
                                    type="radio"
                                    name="sexo"
                                    id="mujer"
                                    value="Mujer"
                                    required>

                                <label class="form-check-label" for="mujer">
                                    Mujer
                                </label>
                            </div>

                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="foto" class="form-label">
                            Fotografía del Aspirante:
                        </label>

                        <input
                            type="file"
                            class="form-control"
                            id="foto"
                            name="foto"
                            accept=".png,.jpg,.jpeg,.gif,.webp"
                            required>
                    </div>

                    <div class="d-grid">
                        <button type="submit" class="btn btn-primary">
                            Registrar Aspirante
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </section>

</main>

<?php 
include 'includes/footer.php'; 
?>